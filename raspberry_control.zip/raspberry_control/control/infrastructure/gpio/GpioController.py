
class GpioController:
    inc     = "INCREASE"
    up_down = "UP_DOWN"

    def __init__(self, name):        
        pass

    def toggle_output(self, output):
        pass

    def set_output_hight(self, output):
        pass
    
    def set_output_low(self, output):
        pass